clear;
clc;
%=========================����Ŀ�꺯��======================================
%%��Ŀ�꺯��Ϊfi=a(i)+b(i)x(i)+c(i))x(i)^2
%%����Ŀ�꺯��
N=5;
n=1;
c=[0.04,0.03,0.035,0.03,0.04];%������ú����Ķ�����ϵ��
b=[2,3,4,4,2.5];
P=380;                                                           %�ܵĸ�������
% P=100;
p=[80,90,70,70,80]; 
tend=5000; 

afa=0.6*[0.006 0.007 0.005 0.007 0.005 0.007];
eta=0.5*[0.006 0.007 0.005 0.007 0.005 0.007];
%% ��������
   A=     [ 1   0   0    1   1;
            0   1   1    0   1;
            0   1   1    1   0;
            1   0   1    1   0;
            1   1   0    0   1];%�ڽӾ���  %ʱ��
for i=1:N
        N_in(i)=0;
    for j=1:N
        if A(i,j)>0;
           N_in(i)=N_in(i)+1;
        end
    end
end
N_in;   %���˽ṹ�����

for i=1:N
        N_out(i)=0;
    for j=1:N
        if A(j,i)>0;
           N_out(i)=N_out(i)+1;
        end
    end
end
N_out;  %���˽ṹ�ĳ���

for i=1:N
    for j=1:N
        if A(i,j)>0
           R1(i,j)=1/N_in(i);
        else
           R1(i,j)=0;
        end
    end
end

    for i=1:N
        for j=1:N
            if A(j,i)>0;
                C1(i,j)=1/( N_out(j));
            else
                C1(i,j)=0;
                end
            end
    end
C1%���������
R1 %���������
%% �����㷨����
h=0.022;
gamma=0.989;
C=0.2;
x=cell(N,1);
lambda=cell(N,1);
y=cell(N,1);
z=cell(N,1);
lambda_sample_data=cell(N,1);
y_sample_data=cell(N,1);
v1=cell(N,1);
v2=cell(N,1);
v_lambda=cell(N,1);
v_y=cell(N,1);

e_lambda=cell(N,1);
e_y=cell(N,1);
e_paint=cell(N,1);
e_hat=cell(N,1);

x_sample_instant=cell(N,1); 
lambda_sample_instant=cell(N,1);
y_sample_instant=cell(N,1);

for i=1:N
     for j=1:n     
         lambda{i}(j,1)=0*rand;  %x�ĳ�ʼ��
     end 
end

for i=1:N
     for j=1:n 
     x{i}(j,1)=40; 
   end 
end
% for i=1:N                      % ��ʼ�� x
%     for j=1:n
%         x{i}(j,1)=-8+16*rand;
%     end
% end
for i=1:N                      % ��ʼ�� y
    for j=1:n
        y{i}(j,1)=-x{i}(j,1)+P/N;
    end
end
for i=1:N                      % ��ʼ��  v_lambda
     for j=1:n
         v_lambda{i}(j,1)=lambda{i}(j,1);
     end
 end
for i=1:N                      % ��ʼ��  v_y
     for j=1:n
         v_y{i}(j,1)= y{i}(j,1);
     end
end


for i=1:N                      % ��ʼ�� lambda �Ĳ���ֵ
    for j=1:n
        lambda_sample_data{i}(j,1)=lambda{i}(j,1);
    end
end

% for i=1:N                      % ��ʼ�� x �Ĳ���ֵ
%     for j=1:n
%         x_sample_data{i}(j,1)=x{i}(j,1);
%     end
% end
 
for i=1:N                      % ��ʼ�� y �Ĳ���ֵ
    for j=1:n
        y_sample_data{i}(j,1)=y{i}(j,1);
    end
end

for i=1:N           
     for j=1:n
         e_lambda{i}(j,1)=0; 
         e_y{i}(j,1)=0;
     end
         e_paint{i}(1,1)=norm(e_lambda{i}(:,1))+norm(e_y{i}(:,1));  %ȡ����
         e_hat{i}(1,1)=0;
end
nbr=zeros(N,1);
for i=1:N
    
    lambda_sample_instant{i}(1,1)=i;  %Ϊ������ÿ��������ı仯��������ֵ��
end

t=1;m=1;

while t<tend
for i=1:N
    if (-lambda{i}(1,m)-b(i))/(2*c(i))<0
       projection{i}(1,m)=0;
    elseif (-lambda{i}(1,m)-b(i))/(2*c(i))>p(i)
      projection{i}(1,m)=p(i); 
    else
      projection{i}(1,m)= (-lambda{i}(1,m)-b(i))/(2*c(i));
    end
      x{i}(1,m+1)=projection{i}(1,m);
end
 
   for i=1:N
            for j=1:n
                v1{i}(j,t)=0;%��ʼ��v_x^[i](k-1)
                v2{i}(j,t)=0;%��ʼ��v_x^[i](k-1)
                for k=1:N
                    v1{i}(j,t)=v1{i}(j,t)+h*A(i,k)*(lambda_sample_data{k}(j,t)-lambda_sample_data{i}(j,t));
                    v2{i}(j,t)=v2{i}(j,t)+h*A(i,k)*(y_sample_data{k}(j,t)-y_sample_data{i}(j,t));
                end
                    v_lambda{i}(j,t)=lambda{i}(j,t)+v1{i}(j,t);
                    v_y{i}(j,t)=y{i}(j,t)+v2{i}(j,t);
            end
  end 
 
for i=1:N
            for j=1:n
                if t==1
                   z{i}(j,m+1)= v_lambda{i}(j,m)-afa(i)* y{i}(j,t);
                else
                   z{i}(j,m+1)= v_lambda{i}(j,m)+eta(i)*(z{i}(j,t)-z{i}(j,t-1))-afa(i)* y{i}(j,t); 
                end
                lambda{i}(j,m+1)=z{i}(j,m+1)-eta(i)*(z{i}(j,m+1)-z{i}(j,m));
                 
            end
                e_lambda{i}(:,m)=lambda_sample_data{i}(:,m)-lambda{i}(:,m);
                e_y{i}(:,m)=y_sample_data{i}(:,m)-y{i}(:,m); 
                e_hat{i}(1,m)=C*((gamma).^t);
            if (norm(e_lambda{i}(:,m),2)+norm(e_y{i}(:,m),2)-e_hat{i}(1,m))>0 
                e_paint{i}(1,m)=0;
                e_paint{i}(1,m)=e_hat{i}(1,m);  
                lambda_sample_data{i}(:,m+1)=lambda{i}(:,m+1);
                lambda_sample_instant{i}(1,m)=i;
                nbr(i,1)=1+ nbr(i,1);
            else
                e_paint{i}(1,m)=norm(e_lambda{i}(:,m))+norm(e_y{i}(:,m));
                lambda_sample_data{i}(:,m+1)=lambda{i}(:,m);
                lambda_sample_instant{i}(1,m)=0;
            end
end 
for i=1:N
            for j=1:n
                y{i}(j,m+1)=v_y{i}(j,m)+x{i}(j,t)-x{i}(j,m+1);
            end                    
         if (norm(e_lambda{i}(:,m),2)+norm(e_y{i}(:,m),2)-e_hat{i}(1,m))>0      
                y_sample_data{i}(:,m+1)=y{i}(:,m+1);
         else
                y_sample_data{i}(:,m+1)=y_sample_data{i}(:,m);
         end
end

 m=m+1;
 t=t+1;
end %% Main Program End

%% ����ʽ�㷨
afa_c=0.6*[0.006 0.007 0.005 0.007 0.005 0.007];
x_c=cell(N,1);
lambda_c=zeros;  %x�ĳ�ʼ��

for i=1:N
     for j=1:n     
         x_c{i}(j,1)=40;  %x�ĳ�ʼ��
     end 
end
m1=1;
while m1<tend
for i=1:N
    if (lambda_c(m1)-b(i))/(2*c(i))<0
       projection_c{i}(1,m1)=0;
    elseif (lambda_c(m1)-b(i))/(2*c(i))>p(i)
      projection_c{i}(1,m1)=p(i); 
    else
      projection_c{i}(1,m1)= (lambda_c(m1)-b(i))/(2*c(i));
    end
      x_c{i}(1,m1+1)=projection_c{i}(1,m1);
end    
    v_x_c=0;
for i=1:N
    v_x_c=v_x_c+x_c{i}(1,m1+1);                         %���lambda�ĵ������̣�����lambda_i(k+1).
end
    lambda_c(m1+1)=lambda_c(m1)-afa_c(i)*(v_x_c-P);    
m1=m1+1;
end

%% wang �㷨
afa_w=0.6*[0.006 0.007 0.005 0.007 0.005 0.007];   %�칹����
h_w=0.022;
gamma_w=0.989;
C_w=0.2;
x_w=cell(N,1);
lambda_w=cell(N,1);
y_w=cell(N,1);
lambda_sample_data_w=cell(N,1);
y_sample_data_w=cell(N,1);
v1_w=cell(N,1);
v2_w=cell(N,1);
v_lambda_w=cell(N,1);
v_y_w=cell(N,1);

e_lambda_w=cell(N,1);
e_y_w=cell(N,1);
e_paint_w=cell(N,1);
e_hat_w=cell(N,1);

x_sample_instant_w=cell(N,1); 
lambda_sample_instant_w=cell(N,1);
y_sample_instant_w=cell(N,1);

for i=1:N
     for j=1:n     
         lambda_w{i}(j,1)=0*rand;  %x�ĳ�ʼ��
     end 
end

for i=1:N
     for j=1:n 
     x_w{i}(j,1)=40; 
      end 
end

for i=1:N                      % ��ʼ�� y
    for j=1:n
        y_w{i}(j,1)=-x_w{i}(j,1)+P/N;
    end
end
for i=1:N                      % ��ʼ��  v_lambda
     for j=1:n
         v_lambda_w{i}(j,1)=lambda_w{i}(j,1);
     end
 end
for i=1:N                      % ��ʼ��  v_y
     for j=1:n
         v_y_w{i}(j,1)= y_w{i}(j,1);
     end
end


for i=1:N                      % ��ʼ�� lambda �Ĳ���ֵ
    for j=1:n
        lambda_sample_data_w{i}(j,1)=lambda_w{i}(j,1);
    end
end
 
for i=1:N                      % ��ʼ�� y �Ĳ���ֵ
    for j=1:n
        y_sample_data_w{i}(j,1)=y_w{i}(j,1);
    end
end

for i=1:N           
     for j=1:n
         e_lambda_w{i}(j,1)=0; 
         e_y_w{i}(j,1)=0;
     end
         e_paint_w{i}(1,1)=norm(e_lambda_w{i}(:,1))+norm(e_y_w{i}(:,1));  %ȡ����
         e_hat_w{i}(1,1)=0;
end

for i=1:N
    
    lambda_sample_instant_w{i}(1,1)=i;  %Ϊ������ÿ��������ı仯��������ֵ��
end

t_w=1;m_w=1;

while t_w<tend
for i=1:N
    if (-lambda_w{i}(1,m_w)-b(i))/(2*c(i))<0
       projection_w{i}(1,m_w)=0;
    elseif (-lambda_w{i}(1,m_w)-b(i))/(2*c(i))>p(i)
      projection_w{i}(1,m_w)=p(i); 
    else
      projection_w{i}(1,m_w)= (-lambda_w{i}(1,m_w)-b(i))/(2*c(i));
    end
      x_w{i}(1,m_w+1)=projection_w{i}(1,m_w);
end
 
   for i=1:N
            for j=1:n
                v1_w{i}(j,t_w)=0;%��ʼ��v_x^[i](k-1)
                v2_w{i}(j,t_w)=0;%��ʼ��v_x^[i](k-1)
                for k=1:N
                    v1_w{i}(j,t_w)=v1_w{i}(j,t_w)+h*A(i,k)*(lambda_sample_data_w{k}(j,t_w)-lambda_sample_data_w{i}(j,t_w));
                    v2_w{i}(j,t_w)=v2_w{i}(j,t_w)+h*A(i,k)*(y_sample_data_w{k}(j,t_w)-y_sample_data_w{i}(j,t_w));
                end
                    v_lambda_w{i}(j,t_w)=lambda_w{i}(j,t_w)+v1_w{i}(j,t_w);
                    v_y_w{i}(j,t_w)=y_w{i}(j,t_w)+v2_w{i}(j,t_w);
            end
  end 
 
for i=1:N
            for j=1:n
                lambda_w{i}(j,m_w+1)=v_lambda_w{i}(j,m_w)-afa_w(i)* y_w{i}(j,t_w);
                 
            end
                e_lambda_w{i}(:,m_w)=lambda_sample_data_w{i}(:,m_w)-lambda_w{i}(:,m_w);
                e_y_w{i}(:,m_w)=y_sample_data_w{i}(:,m_w)-y_w{i}(:,m_w); 
                e_hat_w{i}(1,m_w)=C_w*((gamma_w).^t);
            if (norm(e_lambda_w{i}(:,m_w),2)+norm(e_y_w{i}(:,m_w),2)-e_hat_w{i}(1,m_w))>0 
                e_paint_w{i}(1,m_w)=0;
                e_paint_w{i}(1,m_w)=e_hat_w{i}(1,m_w);  
                lambda_sample_data_w{i}(:,m_w+1)=lambda_w{i}(:,m_w+1);
                lambda_sample_instant_w{i}(1,m_w)=i;
            else
                e_paint_w{i}(1,m_w)=norm(e_lambda_w{i}(:,m_w))+norm(e_y_w{i}(:,m_w));
                lambda_sample_data_w{i}(:,m_w+1)=lambda_w{i}(:,m_w);
                lambda_sample_instant_w{i}(1,m_w)=0;
            end
end 
for i=1:N
            for j=1:n
                y_w{i}(j,m_w+1)=v_y_w{i}(j,m_w)+x_w{i}(j,t_w)-x_w{i}(j,m_w+1);
            end                    
         if (norm(e_lambda_w{i}(:,m_w),2)+norm(e_y_w{i}(:,m_w),2)-e_hat_w{i}(1,m_w))>0      
                y_sample_data_w{i}(:,m_w+1)=y_w{i}(:,m_w+1);
         else
                y_sample_data_w{i}(:,m_w+1)=y_sample_data_w{i}(:,m_w);
         end
end

 m_w=m_w+1;
 t_w=t_w+1;
end %% Main Program End
%% ���¼�����+�޼�����--TT Doan
x_t=cell(N,1);
lambda_t=cell(N,1);
y_t=cell(N,1);
afa_t=0.7*[0.006 0.007 0.005 0.007 0.005 0.007];
for i=1:N
     for j=1:n     
         lambda_t{i}(j,1)=0*rand;  %x�ĳ�ʼ��
     end 
end

for i=1:N
     for j=1:n 
         x_t{i}(j,1)=40; 
     end 
end

for i=1:N                      % ��ʼ�� y
    for j=1:n
        y_t{i}(j,1)=-x_t{i}(j,1)+P/N;
    end
end

m_t=1;

while m_t<tend
for i=1:N
    if (-lambda_t{i}(1,m_t)-b(i))/(2*c(i))<0
       projection_t{i}(1,m_t)=0;
    elseif (-lambda_t{i}(1,m_t)-b(i))/(2*c(i))>p(i)
      projection_t{i}(1,m_t)=p(i); 
    else
      projection_t{i}(1,m_t)= (-lambda_t{i}(1,m_t)-b(i))/(2*c(i));
    end
      x_t{i}(1,m_t+1)=projection_t{i}(1,m_t);
end
 
   for i=1:N
            for j=1:n
                v1_t{i}(j,m_t)=0;%��ʼ��v_x^[i](k-1)
                v2_t{i}(j,m_t)=0;%��ʼ��v_x^[i](k-1)
                for k=1:N
                    v1_t{i}(j,m_t)=v1_t{i}(j,m_t)+R1(i,k)*lambda_t{k}(j,m_t);
                    v2_t{i}(j,m_t)=v2_t{i}(j,m_t)+R1(i,k)*y_t{k}(j,m_t);
                end
            end
   end 
    
 
for i=1:N
            for j=1:n
                lambda_t{i}(j,m_t+1)=v1_t{i}(j,m_t)-afa_t(i)*y_t{i}(j,m_t);
                y_t{i}(j,m_t+1)=v2_t{i}(j,m_t)+x_t{i}(j,m_t)-x_t{i}(j,m_t+1); 
            end
end


 m_t=m_t+1;
end %% Main Program End
%% ���¼�����+�޼�����--zhao
x_z=cell(N,1);
lambda_z=cell(N,1);
y_z=cell(N,1);
afa_z=0.6*[0.006 0.007 0.005 0.007 0.005 0.007];
for i=1:N
     for j=1:n     
         lambda_z{i}(j,1)=0*rand;  %x�ĳ�ʼ��
     end 
end

for i=1:N
     for j=1:n 
         x_z{i}(j,1)=40; 
     end 
end

for i=1:N                      % ��ʼ�� y
    for j=1:n
        y_z{i}(j,1)=-x_z{i}(j,1)+P/N;
    end
end

m_z=1;

while m_z<tend
for i=1:N
    if (-lambda_z{i}(1,m_z)-b(i))/(2*c(i))<0
       projection_z{i}(1,m_z)=0;
    elseif (-lambda_z{i}(1,m_z)-b(i))/(2*c(i))>p(i)
      projection_z{i}(1,m_z)=p(i); 
    else
      projection_z{i}(1,m_z)= (-lambda_z{i}(1,m_z)-b(i))/(2*c(i));
    end
      x_z{i}(1,m_z+1)=projection_z{i}(1,m_z);
end
 
   for i=1:N
            for j=1:n
                v1_z{i}(j,m_z)=0;%��ʼ��v_x^[i](k-1)
                v2_z{i}(j,m_z)=0;%��ʼ��v_x^[i](k-1)
                for k=1:N
                    v1_z{i}(j,m_z)=v1_z{i}(j,m_z)+R1(i,k)*lambda_z{k}(j,m_z);
                    v2_z{i}(j,m_z)=v2_z{i}(j,m_z)+C1(i,k)*y_z{k}(j,m_z);
                end
            end
   end 
    
 
for i=1:N
            for j=1:n
                lambda_z{i}(j,m_z+1)=v1_z{i}(j,m_z)-afa_z(i)*y_z{i}(j,m_z);
                y_z{i}(j,m_z+1)=v2_z{i}(j,m_z)+x_z{i}(j,m_z)-x_z{i}(j,m_z+1); 
            end
end


 m_z=m_z+1;
end %% Main Program End
%% ��ͬ������ϵ��1
h_1=0.022;
gamma_1=0.989;
C_1=0.2;
x_1=cell(N,1);
lambda_1=cell(N,1);
y_1=cell(N,1);
z_1=cell(N,1);
lambda_sample_data_1=cell(N,1);
y_sample_data_1=cell(N,1);
v1_1=cell(N,1);
v2_1=cell(N,1);
v_lambda_1=cell(N,1);
v_y_1=cell(N,1);

e_lambda_1=cell(N,1);
e_y_1=cell(N,1);
e_paint_1=cell(N,1);
e_hat_1=cell(N,1);

x_sample_instant_1=cell(N,1); 
lambda_sample_instant_1=cell(N,1);
y_sample_instant_1=cell(N,1);
afa_1=0.2*[0.006 0.007 0.005 0.007 0.005 0.007];
eta_1=0.5*[0.006 0.007 0.005 0.007 0.005 0.007];
for i=1:N
     for j=1:n     
         lambda_1{i}(j,1)=0*rand;  %x�ĳ�ʼ��
     end 
end

for i=1:N
     for j=1:n     
         x_1{i}(j,1)=40;  %x�ĳ�ʼ��
     end 
end

for i=1:N                      % ��ʼ�� y
    for j=1:n
        y_1{i}(j,1)=-x_1{i}(j,1)+P/N;
    end
end
for i=1:N                      % ��ʼ��  v_lambda
     for j=1:n
         v_lambda_1{i}(j,1)=lambda_1{i}(j,1);
     end
 end
for i=1:N                      % ��ʼ��  v_y
     for j=1:n
         v_y_1{i}(j,1)= y_1{i}(j,1);
     end
end


for i=1:N                      % ��ʼ�� lambda �Ĳ���ֵ
    for j=1:n
        lambda_sample_data_1{i}(j,1)=lambda_1{i}(j,1);
    end
end
 
for i=1:N                      % ��ʼ�� y �Ĳ���ֵ
    for j=1:n
        y_sample_data_1{i}(j,1)=y_1{i}(j,1);
    end
end

for i=1:N           
     for j=1:n
         e_lambda_1{i}(j,1)=0; 
         e_y_1{i}(j,1)=0;
     end
         e_paint_1{i}(1,1)=norm(e_lambda_1{i}(:,1))+norm(e_y_1{i}(:,1));  %ȡ����
         e_hat_1{i}(1,1)=0;
end

for i=1:N
    lambda_sample_instant_1{i}(1,1)=i;  %Ϊ������ÿ��������ı仯��������ֵ��
end

t_1=1;m_1=1;

while t_1<tend
for i=1:N
    if (-lambda_1{i}(1,m_1)-b(i))/(2*c(i))<0
       projection{i}(1,m_1)=0;
    elseif (-lambda_1{i}(1,m_1)-b(i))/(2*c(i))>p(i)
      projection{i}(1,m_1)=p(i); 
    else
      projection{i}(1,m_1)= (-lambda_1{i}(1,m_1)-b(i))/(2*c(i));
    end
      x_1{i}(1,m_1+1)=projection{i}(1,m_1);
end
 
   for i=1:N
            for j=1:n
                v1_1{i}(j,t_1)=0;%��ʼ��v_x^[i](k-1)
                v2_1{i}(j,t_1)=0;%��ʼ��v_x^[i](k-1)
                for k=1:N
                    v1_1{i}(j,t_1)=v1_1{i}(j,t_1)+h_1*A(i,k)*(lambda_sample_data_1{k}(j,t_1)-lambda_sample_data_1{i}(j,t_1));
                    v2_1{i}(j,t_1)=v2_1{i}(j,t_1)+h_1*A(i,k)*(y_sample_data_1{k}(j,t_1)-y_sample_data_1{i}(j,t_1));
                end
                    v_lambda_1{i}(j,t_1)=lambda_1{i}(j,t_1)+v1_1{i}(j,t_1);
                    v_y_1{i}(j,t_1)=y_1{i}(j,t_1)+v2_1{i}(j,t_1);
            end
  end 
 
for i=1:N
            for j=1:n
                if t_1==1
                   z_1{i}(j,m_1+1)= v_lambda_1{i}(j,m_1)-afa_1(i)* y_1{i}(j,t_1);
                else
                   z_1{i}(j,m_1+1)= v_lambda_1{i}(j,m_1)+eta_1(i)*(z_1{i}(j,t_1)-z_1{i}(j,t_1-1))-afa_1(i)* y_1{i}(j,t_1); 
                end
                lambda_1{i}(j,m_1+1)=z_1{i}(j,m_1+1)-eta_1(i)*(z_1{i}(j,m_1+1)-z_1{i}(j,m_1));
                 
            end
                e_lambda_1{i}(:,m_1)=lambda_sample_data_1{i}(:,m_1)-lambda_1{i}(:,m_1);
                e_y_1{i}(:,m_1)=y_sample_data_1{i}(:,m_1)-y_1{i}(:,m_1); 
                e_hat_1{i}(1,m_1)=C_1*((gamma_1).^t_1);
            if (norm(e_lambda_1{i}(:,m_1),2)+norm(e_y_1{i}(:,m_1),2)-e_hat_1{i}(1,m_1))>0 
                e_paint_1{i}(1,m_1)=0;
                e_paint_1{i}(1,m_1)=e_hat_1{i}(1,m_1);  
                lambda_sample_data_1{i}(:,m_1+1)=lambda_1{i}(:,m_1+1);
                lambda_sample_instant_1{i}(1,m_1)=i;
            else
                e_paint_1{i}(1,m_1)=norm(e_lambda_1{i}(:,m_1))+norm(e_y_1{i}(:,m_1));
                lambda_sample_data_1{i}(:,m_1+1)=lambda_1{i}(:,m_1);
                lambda_sample_instant_1{i}(1,m_1)=0;
            end
end 
for i=1:N
            for j=1:n
                y_1{i}(j,m_1+1)=v_y_1{i}(j,m_1)+x_1{i}(j,t_1)-x_1{i}(j,m_1+1);
            end                    
         if (norm(e_lambda_1{i}(:,m_1),2)+norm(e_y_1{i}(:,m_1),2)-e_hat_1{i}(1,m_1))>0      
                y_sample_data_1{i}(:,m_1+1)=y_1{i}(:,m_1+1);
         else
                y_sample_data_1{i}(:,m_1+1)=y_sample_data_1{i}(:,m_1);
         end
end

 m_1=m_1+1;
 t_1=t_1+1;
end %% Main Program End
%% ��ͬ������ϵ��2
h_2=0.022;
gamma_2=0.989;
C_2=0.2;
x_2=cell(N,1);
lambda_2=cell(N,1);
y_2=cell(N,1);
z_2=cell(N,1);
lambda_sample_data_2=cell(N,1);
y_sample_data_2=cell(N,1);
v1_2=cell(N,1);
v2_2=cell(N,1);
v_lambda_2=cell(N,1);
v_y_2=cell(N,1);

e_lambda_2=cell(N,1);
e_y_2=cell(N,1);
e_paint_2=cell(N,1);
e_hat_2=cell(N,1);

x_sample_instant_2=cell(N,1); 
lambda_sample_instant_2=cell(N,1);
y_sample_instant_2=cell(N,1);
afa_2=0.3*[0.006 0.007 0.005 0.007 0.005 0.007];
eta_2=0.5*[0.006 0.007 0.005 0.007 0.005 0.007];
for i=1:N
     for j=1:n     
         lambda_2{i}(j,1)=0*rand;  %x�ĳ�ʼ��
     end 
end

for i=1:N
     for j=1:n     
         x_2{i}(j,1)=40;  %x�ĳ�ʼ��
     end 
end

for i=1:N                      % ��ʼ�� y
    for j=1:n
        y_2{i}(j,1)=-x_2{i}(j,1)+P/N;
    end
end
for i=1:N                      % ��ʼ��  v_lambda
     for j=1:n
         v_lambda_2{i}(j,1)=lambda_2{i}(j,1);
     end
 end
for i=1:N                      % ��ʼ��  v_y
     for j=1:n
         v_y_2{i}(j,1)= y_2{i}(j,1);
     end
end


for i=1:N                      % ��ʼ�� lambda �Ĳ���ֵ
    for j=1:n
        lambda_sample_data_2{i}(j,1)=lambda_2{i}(j,1);
    end
end
 
for i=1:N                      % ��ʼ�� y �Ĳ���ֵ
    for j=1:n
        y_sample_data_2{i}(j,1)=y_2{i}(j,1);
    end
end

for i=1:N           
     for j=1:n
         e_lambda_2{i}(j,1)=0; 
         e_y_2{i}(j,1)=0;
     end
         e_paint_2{i}(1,1)=norm(e_lambda_2{i}(:,1))+norm(e_y_2{i}(:,1));  %ȡ����
         e_hat_2{i}(1,1)=0;
end

for i=1:N
    lambda_sample_instant_2{i}(1,1)=i;  %Ϊ������ÿ��������ı仯��������ֵ��
end

t_2=1;m_2=1;

while t_2<tend
for i=1:N
    if (-lambda_2{i}(1,m_2)-b(i))/(2*c(i))<0
       projection{i}(1,m_2)=0;
    elseif (-lambda_2{i}(1,m_2)-b(i))/(2*c(i))>p(i)
      projection{i}(1,m_2)=p(i); 
    else
      projection{i}(1,m_2)= (-lambda_2{i}(1,m_2)-b(i))/(2*c(i));
    end
      x_2{i}(1,m_2+1)=projection{i}(1,m_2);
end
 
   for i=1:N
            for j=1:n
                v1_2{i}(j,t_2)=0;%��ʼ��v_x^[i](k-1)
                v2_2{i}(j,t_2)=0;%��ʼ��v_x^[i](k-1)
                for k=1:N
                    v1_2{i}(j,t_2)=v1_2{i}(j,t_2)+h_2*A(i,k)*(lambda_sample_data_2{k}(j,t_2)-lambda_sample_data_2{i}(j,t_2));
                    v2_2{i}(j,t_2)=v2_2{i}(j,t_2)+h_2*A(i,k)*(y_sample_data_2{k}(j,t_2)-y_sample_data_2{i}(j,t_2));
                end
                    v_lambda_2{i}(j,t_2)=lambda_2{i}(j,t_2)+v1_2{i}(j,t_2);
                    v_y_2{i}(j,t_2)=y_2{i}(j,t_2)+v2_2{i}(j,t_2);
            end
  end 
 
for i=1:N
            for j=1:n
                if t_2==1
                   z_2{i}(j,m_2+1)= v_lambda_2{i}(j,m_2)-afa_2(i)* y_2{i}(j,t_2);
                else
                   z_2{i}(j,m_2+1)= v_lambda_2{i}(j,m_2)+eta_2(i)*(z_2{i}(j,t_2)-z_2{i}(j,t_2-1))-afa_2(i)* y_2{i}(j,t_2); 
                end
                lambda_2{i}(j,m_2+1)=z_2{i}(j,m_2+1)-eta_2(i)*(z_2{i}(j,m_2+1)-z_2{i}(j,m_2));
                 
            end
                e_lambda_2{i}(:,m_2)=lambda_sample_data_2{i}(:,m_2)-lambda_2{i}(:,m_2);
                e_y_2{i}(:,m_2)=y_sample_data_2{i}(:,m_2)-y_2{i}(:,m_2); 
                e_hat_2{i}(1,m_2)=C_2*((gamma_2).^t_2);
            if (norm(e_lambda_2{i}(:,m_2),2)+norm(e_y_2{i}(:,m_2),2)-e_hat_2{i}(1,m_2))>0 
                e_paint_2{i}(1,m_2)=0;
                e_paint_2{i}(1,m_2)=e_hat_2{i}(1,m_2);  
                lambda_sample_data_2{i}(:,m_2+1)=lambda_2{i}(:,m_2+1);
                lambda_sample_instant_2{i}(1,m_2)=i;
            else
                e_paint_2{i}(1,m_2)=norm(e_lambda_2{i}(:,m_2))+norm(e_y_2{i}(:,m_2));
                lambda_sample_data_2{i}(:,m_2+1)=lambda_2{i}(:,m_2);
                lambda_sample_instant_2{i}(1,m_2)=0;
            end
end 
for i=1:N
            for j=1:n
                y_2{i}(j,m_2+1)=v_y_2{i}(j,m_2)+x_2{i}(j,t_2)-x_2{i}(j,m_2+1);
            end                    
         if (norm(e_lambda_2{i}(:,m_2),2)+norm(e_y_2{i}(:,m_2),2)-e_hat_2{i}(1,m_2))>0      
                y_sample_data_2{i}(:,m_2+1)=y_2{i}(:,m_2+1);
         else
                y_sample_data_2{i}(:,m_2+1)=y_sample_data_2{i}(:,m_2);
         end
end

 m_2=m_2+1;
 t_2=t_2+1;
end %% Main Program End
%% ��ͬ������ϵ��3
h_3=0.022;
gamma_3=0.989;
C_3=0.2;
afa_3=0.4*[0.006 0.007 0.005 0.007 0.005 0.007];
eta_3=0.5*[0.006 0.007 0.005 0.007 0.005 0.007];
x_3=cell(N,1);
lambda_3=cell(N,1);
y_3=cell(N,1);
z_3=cell(N,1);
lambda_sample_data_3=cell(N,1);
y_sample_data_3=cell(N,1);
v1_3=cell(N,1);
v2_3=cell(N,1);
v_lambda_3=cell(N,1);
v_y_3=cell(N,1);

e_lambda_3=cell(N,1);
e_y_3=cell(N,1);
e_paint_3=cell(N,1);
e_hat_3=cell(N,1);

x_sample_instant_3=cell(N,1); 
lambda_sample_instant_3=cell(N,1);
y_sample_instant_3=cell(N,1);

for i=1:N
     for j=1:n     
         lambda_3{i}(j,1)=0*rand;  %x�ĳ�ʼ��
     end 
end

for i=1:N
     for j=1:n     
         x_3{i}(j,1)=40;  %x�ĳ�ʼ��
     end 
end

for i=1:N                      % ��ʼ�� y
    for j=1:n
        y_3{i}(j,1)=-x_3{i}(j,1)+P/N;
    end
end
for i=1:N                      % ��ʼ��  v_lambda
     for j=1:n
         v_lambda_3{i}(j,1)=lambda_3{i}(j,1);
     end
 end
for i=1:N                      % ��ʼ��  v_y
     for j=1:n
         v_y_3{i}(j,1)= y_3{i}(j,1);
     end
end


for i=1:N                      % ��ʼ�� lambda �Ĳ���ֵ
    for j=1:n
        lambda_sample_data_3{i}(j,1)=lambda_3{i}(j,1);
    end
end
 
for i=1:N                      % ��ʼ�� y �Ĳ���ֵ
    for j=1:n
        y_sample_data_3{i}(j,1)=y_3{i}(j,1);
    end
end

for i=1:N           
     for j=1:n
         e_lambda_3{i}(j,1)=0; 
         e_y_3{i}(j,1)=0;
     end
         e_paint_3{i}(1,1)=norm(e_lambda_3{i}(:,1))+norm(e_y_3{i}(:,1));  %ȡ����
         e_hat_3{i}(1,1)=0;
end

for i=1:N
    lambda_sample_instant_3{i}(1,1)=i;  %Ϊ������ÿ��������ı仯��������ֵ��
end

t_3=1;m_3=1;

while t_3<tend
for i=1:N
    if (-lambda_3{i}(1,m_3)-b(i))/(2*c(i))<0
       projection{i}(1,m_3)=0;
    elseif (-lambda_3{i}(1,m_3)-b(i))/(2*c(i))>p(i)
      projection{i}(1,m_3)=p(i); 
    else
      projection{i}(1,m_3)= (-lambda_3{i}(1,m_3)-b(i))/(2*c(i));
    end
      x_3{i}(1,m_3+1)=projection{i}(1,m_3);
end
 
   for i=1:N
            for j=1:n
                v1_3{i}(j,t_3)=0;%��ʼ��v_x^[i](k-1)
                v2_3{i}(j,t_3)=0;%��ʼ��v_x^[i](k-1)
                for k=1:N
                    v1_3{i}(j,t_3)=v1_3{i}(j,t_3)+h_3*A(i,k)*(lambda_sample_data_3{k}(j,t_3)-lambda_sample_data_3{i}(j,t_3));
                    v2_3{i}(j,t_3)=v2_3{i}(j,t_3)+h_3*A(i,k)*(y_sample_data_3{k}(j,t_3)-y_sample_data_3{i}(j,t_3));
                end
                    v_lambda_3{i}(j,t_3)=lambda_3{i}(j,t_3)+v1_3{i}(j,t_3);
                    v_y_3{i}(j,t_3)=y_3{i}(j,t_3)+v2_3{i}(j,t_3);
            end
  end 
 
for i=1:N
            for j=1:n
                if t_3==1
                   z_3{i}(j,m_3+1)= v_lambda_3{i}(j,m_3)-afa_3(i)* y_3{i}(j,t_3);
                else
                   z_3{i}(j,m_3+1)= v_lambda_3{i}(j,m_3)+eta_3(i)*(z_3{i}(j,t_3)-z_3{i}(j,t_3-1))-afa_3(i)* y_3{i}(j,t_3); 
                end
                lambda_3{i}(j,m_3+1)=z_3{i}(j,m_3+1)-eta_3(i)*(z_3{i}(j,m_3+1)-z_3{i}(j,m_3));
                 
            end
                e_lambda_3{i}(:,m_3)=lambda_sample_data_3{i}(:,m_3)-lambda_3{i}(:,m_3);
                e_y_3{i}(:,m_3)=y_sample_data_3{i}(:,m_3)-y_3{i}(:,m_3); 
                e_hat_3{i}(1,m_3)=C_3*((gamma_3).^t_3);
            if (norm(e_lambda_3{i}(:,m_3),2)+norm(e_y_3{i}(:,m_3),2)-e_hat_3{i}(1,m_3))>0 
                e_paint_3{i}(1,m_3)=0;
                e_paint_3{i}(1,m_3)=e_hat_3{i}(1,m_3);  
                lambda_sample_data_3{i}(:,m_3+1)=lambda_3{i}(:,m_3+1);
                lambda_sample_instant_3{i}(1,m_3)=i;
            else
                e_paint_3{i}(1,m_3)=norm(e_lambda_3{i}(:,m_3))+norm(e_y_3{i}(:,m_3));
                lambda_sample_data_3{i}(:,m_3+1)=lambda_3{i}(:,m_3);
                lambda_sample_instant_3{i}(1,m_3)=0;
            end
end 
for i=1:N
            for j=1:n
                y_3{i}(j,m_3+1)=v_y_3{i}(j,m_3)+x_3{i}(j,t_3)-x_3{i}(j,m_3+1);
            end                    
         if (norm(e_lambda_3{i}(:,m_3),2)+norm(e_y_3{i}(:,m_3),2)-e_hat_3{i}(1,m_3))>0      
                y_sample_data_3{i}(:,m_3+1)=y_3{i}(:,m_3+1);
         else
                y_sample_data_3{i}(:,m_3+1)=y_sample_data_3{i}(:,m_3);
         end
end

 m_3=m_3+1;
 t_3=t_3+1;
end %% Main Program End

%=============================================���岽�����ͼ��================================%

%%
oo=0:tend-1;
len=length(oo);

figure 
x_ck=cell(N,1);
for i=1:N
    x_ck{i}=x_c{i}(1,tend);
end

for i=1:N   
    for t=1:tend      
        c_tp(i,t)=((norm((x{i}(1,t)-x_ck{i}),2)));
        c_c(i,t)=((norm((x_c{i}(1,t)-x_ck{i}),2)));
        c_w(i,t)=((norm((x_w{i}(1,t)-x_ck{i}),2)));
        c_t(i,t)=((norm((x_t{i}(1,t)-x_ck{i}),2)));
        c_z(i,t)=((norm((x_z{i}(1,t)-x_ck{i}),2)));
        c_1(i,t)=((norm((x_1{i}(1,t)-x_ck{i}),2)));
        c_2(i,t)=((norm((x_2{i}(1,t)-x_ck{i}),2)));
        c_3(i,t)=((norm((x_3{i}(1,t)-x_ck{i}),2)));        
    end
    
    f_tp=0;
    f_c=0;
    f_w=0;
    f_t=0;
    f_z=0;
    f_1=0;
    f_2=0;
    f_3=0;
    f_tp=f_tp+c_tp(i,1:tend-500);
    f_c=f_c+c_c(i,1:tend-500);
    f_w=f_w+c_w(i,1:tend-500);
    f_t=f_t+c_t(i,1:tend-500);
    f_z=f_z+c_z(i,1:tend-500);
    f_1=f_1+c_1(i,1:tend-500);
    f_2=f_2+c_2(i,1:tend-500);
    f_3=f_3+c_3(i,1:tend-500);
end

for t=1:tend-500
    l_p(t)=log(f_tp(1,t));
    l_c(t)=log(f_c(1,t));
    l_w(t)=log(f_w(1,t));
    l_t(t)=log(f_t(1,t));
    l_z(t)=log(f_z(1,t));
    l_1(t)=log(f_1(1,t));
    l_2(t)=log(f_2(1,t));
    l_3(t)=log(f_3(1,t));
end

e_tp=plot(l_p);
%axis( [1 tend -30 5] );
set(e_tp,'Linewidth',1.5);
set(e_tp,'color','r');
hold on;

e_tp=plot(l_c);
%axis( [1 tend -30 5] );
set(e_tp,'Linewidth',1.5);
set(e_tp,'color','b');
hold on;

e_tp=plot(l_w);
%axis( [1 tend -30 5] );
set(e_tp,'Linewidth',1.5);
set(e_tp,'color','m');
hold on;

e_tp=plot(l_t);
%axis( [1 tend -30 5] );
set(e_tp,'Linewidth',1.5);
set(e_tp,'color','g');
hold on;

e_tp=plot(l_z);
%axis( [1 tend -30 5] );
set(e_tp,'Linewidth',1.5);
set(e_tp,'color','y');
hold on;

e_ps=plot(l_1);
%axis( [1 tend -30 5] );
set(e_ps,'Linewidth',1.5);
set(e_ps,'color','r');
hold on;

e_tn=plot(l_2);
%axis( [1 tend -30 5] );
set(e_tn,'Linewidth',1.5);
set(e_tn,'color','r');
hold on;

e_tn=plot(l_3);
%axis( [1 tend -30 5] );
set(e_tn,'Linewidth',1.5);
set(e_tn,'color','r');
hold on;

xlabel('Time[step]')
ylabel('Residual');
tq=legend('ET-DAPDA','Centralized','Wang','TT','Zhao','ET-DAPDA1','ET-DAPDA2','ET-DAPDA3');
set(tq,'Interpreter','latex')



% oo=0:tend-1;
% len=length(oo);
% % ���x��ͼ��
% figure(1) 
% for i=1:N
% h=plot(oo,x_2{i}(1,1:len),'linewidth',1.5);
% set(h,'color',[rand,rand,rand]);
% hold on
% end
% xlabel('Iteration')
% ylabel('Individual Generation (kW)')
% legend('x_1','x_2','x_3','x_4','x_5','x_6');
% %% ���lamda��ͼ��
% figure(2)  
% for i=1:N
% h=plot(oo,(lambda_2{i}(1,1:len)),'linewidth',1.5);
% set(h,'color',[rand,rand,rand]);
% hold on
% end
% xlabel('Iteration')
% ylabel('Incremental cost ($/kW)')
% legend('y_1','y_2','y_3','y_4','y_5','y_6'); 