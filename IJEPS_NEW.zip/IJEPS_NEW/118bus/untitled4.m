clear; 
clc; 
tic;
%�ó����ǽ��ʱ�����������������IEEE-118 BUS ���÷������� event-case2-118bus
%������Դhttp://motor.ece.iit.edu/Data/JEAS_IEEE118.doc
%%
%===================================================��һ����������ز�������ʼ��========================================%
N=54;                                             %�������������%
n=1;
h=0.02;
gamma=0.99;
C=1.1;
%������ú����ĳ�����%
a=[31.67,31.67,31.67,6.78,6.78,31.67,10.15,31.67,31.67,6.78,32.96,31.67,31.67,10.15,31.67,10.15,31.67,31.67,10.15,28,28,10.15,10.15,39,39,10.15,64.16,64.16,6.78,74.33,31.67,31.67,17.95,10.15,10.15,6.78,10.15,31.67,32.96,6.78,17.95,58.81,6.78,6.78,6.78,17.95,10.15,10.15,17.95,58.81,10.15,10.15,10.15,58.81];
%������ú�����һ����ϵ��%
b=[26.2438,26.2438,26.2438,12.8875,12.8875,26.2438,17.8200,26.2438,26.2438,12.8875,10.7600,26.2438,26.2438,17.8200,26.2438,17.8200,26.2438,26.2438,17.8200,12.3299,12.3299,17.8200,17.8200,13.2900,13.2900,17.8200,8.3391,8.3391,12.8875,15.4708,26.2438,26.2438,37.6968,17.8200,17.8200,12.8875,17.8200,26.2438,10.7600,12.8875,37.6968,22.9423,12.8875,12.8875,12.8875,37.6968,17.8200,17.8200,37.6968,22.9423,17.8200,17.8200,17.8200,22.9423];   
 %������ú����Ķ�����ϵ��
c=[0.069663,0.069663,0.069663,0.010875,0.010875,0.069663,0.012800,0.069663,0.069663,0.010875,0.003000,0.069663,0.069663,0.012800,0.069663,0.012800,0.069663,0.069663,0.012800,0.002401,0.002401,0.012800,0.012800,0.004400,0.004400,0.012800,0.010590,0.010590,0.010875,0.045923,0.069663,0.069663,0.028302,0.012800,0.012800,0.010875,0.012800,0.069663,0.003000,0.010875,0.028302,0.009774,0.010875,0.010875,0.010875,0.028302,0.012800,0.012800,0.028302,0.009774,0.012800,0.012800,0.012800,0.009774];
l=[5,5,5,150,100,10,25,5,5,100,100,8,8,25,8,25,8,8,25,50,50,25,25,50,50,25,100,100,80,30,10,5,5,25,25,150,25,10,100,50,8,20,100,100,100,8,25,25,8,25,25,25,25,25];
p=[30,30,30,300,300,30,100,30,30,300,350,30,30,100,30,100,30,30,100,250,250,100,100,200,200,100,420,420,300,80,30,30,20,100,100,300,100,30,300,200,20,50,300,300,300,20,100,100,20,50,100,100,100,50];
P=6000;

afa=0.7*[0.006 0.007 0.005 0.007 0.005 0.007 0.006 0.007 0.005 0.007 0.005 0.007 0.006 0.007 0.005 0.007 0.005 0.007 0.006 0.007 0.005 0.007 0.005 0.007 0.006 0.007 0.005 0.007 0.005 0.007 0.006 0.007 0.005 0.007 0.005 0.007 0.006 0.007 0.005 0.007 0.005 0.007 0.006 0.007 0.005 0.007 0.005 0.007 0.006 0.007 0.005 0.007 0.005 0.007];
eta=0.5*[0.006 0.007 0.005 0.007 0.005 0.007 0.006 0.007 0.005 0.007 0.005 0.007 0.006 0.007 0.005 0.007 0.005 0.007 0.006 0.007 0.005 0.007 0.005 0.007 0.006 0.007 0.005 0.007 0.005 0.007 0.006 0.007 0.005 0.007 0.005 0.007 0.006 0.007 0.005 0.007 0.005 0.007 0.006 0.007 0.005 0.007 0.005 0.007 0.006 0.007 0.005 0.007 0.005 0.007];

x=cell(N,1);
x_1=cell(N,1);
lambda=cell(N,1);
y=cell(N,1);
z=cell(N,1);
lambda_sample_data=cell(N,1);
y_sample_data=cell(N,1);
v1=cell(N,1);
v2=cell(N,1);
v_lambda=cell(N,1);
v_y=cell(N,1);

e_lambda=cell(N,1);
e_y=cell(N,1);
e_paint=cell(N,1);
e_hat=cell(N,1);

x_sample_instant=cell(N,1); 
lambda_sample_instant=cell(N,1);
y_sample_instant=cell(N,1);


%���������Գƾ���ʱ��ѭ��%
A=cell(3,1);
A{1}=zeros(N);
n1=N*(N-1)/2;
r=randperm(n1);
a=(r<=300);
temp=triu(true(N),1);
A{1}(temp)=a;
A{1}=A{1}+A{1}';

for i=1:N
     for j=1:n     
         lambda{i}(j,1)=0*rand;  %x�ĳ�ʼ��
     end 
end

for i=1:N
     for j=1:n     
         x_1{i}(j,1)=0;  %x�ĳ�ʼ��
     end 
end
for i=1:N
     for j=1:n 
         x{i}(j,1)=0; 
     end 
end

for i=1:N                      % ��ʼ�� y
    for j=1:n
        y{i}(j,1)=-x{i}(j,1)+P/N;
    end
end
for i=1:N                      % ��ʼ��  v_lambda
     for j=1:n
         v_lambda{i}(j,1)=lambda{i}(j,1);
     end
 end
for i=1:N                      % ��ʼ��  v_y
     for j=1:n
         v_y{i}(j,1)= y{i}(j,1);
     end
end


for i=1:N                      % ��ʼ�� lambda �Ĳ���ֵ
    for j=1:n
        lambda_sample_data{i}(j,1)=lambda{i}(j,1);
    end
end
 
for i=1:N                      % ��ʼ�� y �Ĳ���ֵ
    for j=1:n
        y_sample_data{i}(j,1)=y{i}(j,1);
    end
end

for i=1:N           
     for j=1:n
         e_lambda{i}(j,1)=0; 
         e_y{i}(j,1)=0;
     end
         e_paint{i}(1,1)=norm(e_lambda{i}(:,1))+norm(e_y{i}(:,1));  %ȡ����
         e_hat{i}(1,1)=0;
end
nbr=zeros(N,1);
for i=1:N
    lambda_sample_instant{i}(1,1)=i;  %Ϊ������ÿ��������ı仯��������ֵ��
end

tend=601; t=1;m=1;
%% Main Programm Begin
while t<tend
for i=1:N
    if (-lambda{i}(1,m)-b(i))/(2*c(i))<l(i)
       projection{i}(1,m)=l(i);
    elseif (-lambda{i}(1,m)-b(i))/(2*c(i))>p(i)
      projection{i}(1,m)=p(i); 
    else
      projection{i}(1,m)= (-lambda{i}(1,m)-b(i))/(2*c(i));
    end
      x{i}(1,m+1)=projection{i}(1,m);
end
    
    
 
   for i=1:N
            for j=1:1
                v1{i}(j,t)=0;%��ʼ��v_x^[i](k-1)
                v2{i}(j,t)=0;%��ʼ��v_x^[i](k-1)
                for k=1:N
                   v1{i}(j,t)=v1{i}(j,t)+h*A{1}(i,k)*(lambda_sample_data{k}(j,t)-lambda_sample_data{i}(j,t));
                   v2{i}(j,t)=v2{i}(j,t)+h*A{1}(i,k)*(y_sample_data{k}(j,t)-y_sample_data{i}(j,t));
                end
                    v_lambda{i}(j,t)=lambda{i}(j,t)+v1{i}(j,t);
                    v_y{i}(j,t)=y{i}(j,t)+v2{i}(j,t);
            end
  end 
 

for i=1:N
            for j=1:n
                if t==1
                   z{i}(j,m+1)= v_lambda{i}(j,m)-afa(i)* y{i}(j,t);
                else
                   z{i}(j,m+1)= v_lambda{i}(j,m)+eta(i)*(z{i}(j,t)-z{i}(j,t-1))-afa(i)* y{i}(j,t); 
                end
                lambda{i}(j,m+1)=z{i}(j,m+1)-eta(i)*(z{i}(j,m+1)-z{i}(j,m));
                 
            end
                e_lambda{i}(:,m)=lambda_sample_data{i}(:,m)-lambda{i}(:,m);
                e_y{i}(:,m)=y_sample_data{i}(:,m)-y{i}(:,m); 
                e_hat{i}(1,m)=C*((gamma).^t);
            if (norm(e_lambda{i}(:,m),2)+norm(e_y{i}(:,m),2)-e_hat{i}(1,m))>0 
                e_paint{i}(1,m)=0;
                e_paint{i}(1,m)=e_hat{i}(1,m);  
                lambda_sample_data{i}(:,m+1)=lambda{i}(:,m+1);
                lambda_sample_instant{i}(1,m)=i;
                nbr(i,1)=1+ nbr(i,1);
            else
                e_paint{i}(1,m)=norm(e_lambda{i}(:,m))+norm(e_y{i}(:,m));
                lambda_sample_data{i}(:,m+1)=lambda{i}(:,m);
                lambda_sample_instant{i}(1,m)=0;
            end
end 
for i=1:N
            for j=1:n
                y{i}(j,m+1)=v_y{i}(j,m)+x{i}(j,t)-x{i}(j,m+1);
            end                    
         if (norm(e_lambda{i}(:,m),2)+norm(e_y{i}(:,m),2)-e_hat{i}(1,m))>0      
                y_sample_data{i}(:,m+1)=y{i}(:,m+1);
         else
                y_sample_data{i}(:,m+1)=y_sample_data{i}(:,m);
         end
end
%% �ܵĵ���     
tt=0;  
for i=1:N
    tt=x{i}(1,m+1)+tt;
end
total(m+1)=tt;   
dd(m+1)=P;
    
    
    
 m=m+1;
 t=t+1;
end %% Main Program End
toc;

ttt=toc

nbr;

cc=0;
for i=1:N
    cc=cc+a(i)+b(i)*x{i}(1,600)+c(i)*x{i}(1,600)*x{i}(1,600);
end
cc

for i=1:N
    x{i}(1,600)
end

oo=0:tend-1;
len=length(oo);
% ���x��ͼ��
figure(1) 
for i=1:N
h=plot(oo,x{i}(1,1:len),'linewidth',1.5);
set(h,'color',[rand,rand,rand]);
hold on
end
xlabel('Iteration')
ylabel('Individual Generation (kW)')
legend('x_1','x_2','x_3','x_4','x_5','x_6');
%% ���lamda��ͼ��
figure(2)  
for i=1:N
h=plot(oo,(lambda{i}(1,1:len)),'linewidth',1.5);
set(h,'color',[rand,rand,rand]);
hold on
end
xlabel('Iteration')
ylabel('Incremental cost ($/kW)')
legend('y_1','y_2','y_3','y_4','y_5','y_6'); 
%% ������������������ͼ��
figure(3)  
plot(oo,total(1:len),'g-','linewidth',1.5);
hold on
plot(oo,dd(1:len),'r-','linewidth',1.5);
hold on
legend('Total Generation','Total Demand')
xlabel('Iteration')
ylabel('Total Generation (kW)')
%% �����������ͼ��
t=0:tend-2;
figure
plot(t,e_hat{1},'LineWidth',1.1);   
hold on
plot(t,e_paint{1}(1,:),'r','LineWidth',1.1);     
xlabel('Time[step]'); ylabel('Measurement error and threshold'); 
%legend('||e_{1}(t)||','C\gamma^t'); 
legend('C\gamma^t','||e_{1}(t)||')
%% ����������ͼ��    
t=0:tend-2;
figure
plot(t,lambda_sample_instant{1},'b.','linewidth',5);           
hold on
plot(t,lambda_sample_instant{2},'g.','linewidth',5);
hold on
plot(t,lambda_sample_instant{3},'r.','linewidth',5);
hold on
plot(t,lambda_sample_instant{4},'c.','linewidth',5);
hold on
plot(t,lambda_sample_instant{5},'m.','linewidth',5);
xlabel('Time[step]'); ylabel('Event sampling  time instants of five generators');
axis([0 tend 0.5 5.5]);   

