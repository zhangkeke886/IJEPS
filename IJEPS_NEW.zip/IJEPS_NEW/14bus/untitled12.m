clear;
clc;
tic;
%=========================����Ŀ�꺯��======================================
%%��Ŀ�꺯��Ϊfi=a(i)+b(i)x(i)+c(i))x(i)^2
%%����Ŀ�꺯��
N=5;
n=1;
h=0.022;
gamma=0.989;
C=0.2;
c=[0.04,0.03,0.035,0.03,0.04];%������ú����Ķ�����ϵ��
b=[2,3,4,4,2.5];
% x_min=[0,0,0,0,0];
% x_max=[80,90,70,70,80];
P=380;                                                           %�ܵĸ�������
% P=100;
p=[80,90,70,70,80]; 
 
x=cell(N,1);
lambda=cell(N,1);
y=cell(N,1);
z=cell(N,1);
lambda_sample_data=cell(N,1);
y_sample_data=cell(N,1);
v1=cell(N,1);
v2=cell(N,1);
v_lambda=cell(N,1);
v_y=cell(N,1);

e_lambda=cell(N,1);
e_y=cell(N,1);
e_paint=cell(N,1);
e_hat=cell(N,1);

x_sample_instant=cell(N,1); 
lambda_sample_instant=cell(N,1);
y_sample_instant=cell(N,1);

afa=0.7*[0.006 0.007 0.005 0.007 0.005 0.007];
eta=0.5*[0.006 0.007 0.005 0.007 0.005 0.007];

   A=     [ 1   0   0    1   1;
            0   1   1    0   1;
            0   1   1    1   0;
            1   0   1    1   0;
            1   1   0    0   1];%�ڽӾ���  %ʱ��

% A=ones(N)/N;     
     

for i=1:N
     for j=1:n     
         lambda{i}(j,1)=0*rand;  %x�ĳ�ʼ��
     end 
end

%  lambda{1}(1,1)=0;            % ��ʼ�� lambda
%  lambda{2}(1,1)=0;
%  lambda{3}(1,1)=0;
%  lambda{4}(1,1)=0;
%  lambda{5}(1,1)=0;
for i=1:N
     for j=1:n     
         x_1{i}(j,1)=40;  %x�ĳ�ʼ��
     end 
end
for i=1:N
     for j=1:n 
     x{i}(j,1)=40; 
   end 
end
% for i=1:N                      % ��ʼ�� x
%     for j=1:n
%         x{i}(j,1)=-8+16*rand;
%     end
% end
for i=1:N                      % ��ʼ�� y
    for j=1:n
        y{i}(j,1)=-x{i}(j,1)+P/N;
    end
end
for i=1:N                      % ��ʼ��  v_lambda
     for j=1:n
         v_lambda{i}(j,1)=lambda{i}(j,1);
     end
 end
for i=1:N                      % ��ʼ��  v_y
     for j=1:n
         v_y{i}(j,1)= y{i}(j,1);
     end
end


for i=1:N                      % ��ʼ�� lambda �Ĳ���ֵ
    for j=1:n
        lambda_sample_data{i}(j,1)=lambda{i}(j,1);
    end
end

% for i=1:N                      % ��ʼ�� x �Ĳ���ֵ
%     for j=1:n
%         x_sample_data{i}(j,1)=x{i}(j,1);
%     end
% end
 
for i=1:N                      % ��ʼ�� y �Ĳ���ֵ
    for j=1:n
        y_sample_data{i}(j,1)=y{i}(j,1);
    end
end

for i=1:N           
     for j=1:n
         e_lambda{i}(j,1)=0; 
         e_y{i}(j,1)=0;
     end
         e_paint{i}(1,1)=norm(e_lambda{i}(:,1))+norm(e_y{i}(:,1));  %ȡ����
         e_hat{i}(1,1)=0;
end
nbr=zeros(N,1);
for i=1:N
    
    lambda_sample_instant{i}(1,1)=i;  %Ϊ������ÿ��������ı仯��������ֵ��
end

tend=601; t=1;m=1;
%% Main Programm Begin
while t<tend
for i=1:N
    if (-lambda{i}(1,m)-b(i))/(2*c(i))<0
       projection{i}(1,m)=0;
    elseif (-lambda{i}(1,m)-b(i))/(2*c(i))>p(i)
      projection{i}(1,m)=p(i); 
    else
      projection{i}(1,m)= (-lambda{i}(1,m)-b(i))/(2*c(i));
    end
      x{i}(1,m+1)=projection{i}(1,m);
end
 
   for i=1:N
            for j=1:n
                v1{i}(j,t)=0;%��ʼ��v_x^[i](k-1)
                v2{i}(j,t)=0;%��ʼ��v_x^[i](k-1)
                for k=1:N
                    v1{i}(j,t)=v1{i}(j,t)+h*A(i,k)*(lambda_sample_data{k}(j,t)-lambda_sample_data{i}(j,t));
                    v2{i}(j,t)=v2{i}(j,t)+h*A(i,k)*(y_sample_data{k}(j,t)-y_sample_data{i}(j,t));
                end
                    v_lambda{i}(j,t)=lambda{i}(j,t)+v1{i}(j,t);
                    v_y{i}(j,t)=y{i}(j,t)+v2{i}(j,t);
            end
  end 
 
for i=1:N
            for j=1:n
                if t==1
                   z{i}(j,m+1)= v_lambda{i}(j,m)-afa(i)* y{i}(j,t);
                else
                   z{i}(j,m+1)= v_lambda{i}(j,m)+eta(i)*(z{i}(j,t)-z{i}(j,t-1))-afa(i)* y{i}(j,t); 
                end
                lambda{i}(j,m+1)=z{i}(j,m+1)-eta(i)*(z{i}(j,m+1)-z{i}(j,m));
                 
            end
                e_lambda{i}(:,m)=lambda_sample_data{i}(:,m)-lambda{i}(:,m);
                e_y{i}(:,m)=y_sample_data{i}(:,m)-y{i}(:,m); 
                e_hat{i}(1,m)=C*((gamma).^t);
            if (norm(e_lambda{i}(:,m),2)+norm(e_y{i}(:,m),2)-e_hat{i}(1,m))>0 
                e_paint{i}(1,m)=0;
                e_paint{i}(1,m)=e_hat{i}(1,m);  
                lambda_sample_data{i}(:,m+1)=lambda{i}(:,m+1);
                lambda_sample_instant{i}(1,m)=i;
                nbr(i,1)=1+ nbr(i,1);
            else
                e_paint{i}(1,m)=norm(e_lambda{i}(:,m))+norm(e_y{i}(:,m));
                lambda_sample_data{i}(:,m+1)=lambda{i}(:,m);
                lambda_sample_instant{i}(1,m)=0;
            end
end 
for i=1:N
            for j=1:n
                y{i}(j,m+1)=v_y{i}(j,m)+x{i}(j,t)-x{i}(j,m+1);
            end                    
         if (norm(e_lambda{i}(:,m),2)+norm(e_y{i}(:,m),2)-e_hat{i}(1,m))>0      
                y_sample_data{i}(:,m+1)=y{i}(:,m+1);
         else
                y_sample_data{i}(:,m+1)=y_sample_data{i}(:,m);
         end
end
%% �ܵĵ���     
tt=0;  
for i=1:N
    tt=x{i}(1,m+1)+tt;
end
total(m+1)=tt;   
dd(m+1)=P;


 m=m+1;
 t=t+1;
end %% Main Program End
nbr
toc;

ttt=toc

cc=0;
for i=1:N
    cc=cc+b(i)*x{i}(1,600)+c(i)*x{i}(1,600)*x{i}(1,600);
end
cc


oo=0:tend-1;
len=length(oo);
% ���x��ͼ��
figure(1) 
for i=1:N
h=plot(oo,x{i}(1,1:len),'linewidth',1.5);
set(h,'color',[rand,rand,rand]);
hold on
end
xlabel('Iteration')
ylabel('Individual Generation (kW)')
legend('x_1','x_2','x_3','x_4','x_5','x_6');
%% ���lamda��ͼ��
figure(2)  
for i=1:N
h=plot(oo,(lambda{i}(1,1:len)),'linewidth',1.5);
set(h,'color',[rand,rand,rand]);
hold on
end
xlabel('Iteration')
ylabel('Incremental cost ($/kW)')
legend('y_1','y_2','y_3','y_4','y_5','y_6'); 
%% ������������������ͼ��
figure(3)  
plot(oo,total(1:len),'g-','linewidth',1.5);
hold on
plot(oo,dd(1:len),'r-','linewidth',1.5);
hold on
legend('Total Generation','Total Demand')
xlabel('Iteration')
ylabel('Total Generation (kW)')
%% �����������ͼ��
t=0:tend-2;
figure
plot(t,e_hat{1},'LineWidth',1.1);   
hold on
plot(t,e_paint{1}(1,:),'r','LineWidth',1.1);     
xlabel('Time[step]'); ylabel('Measurement error and threshold'); 
%legend('||e_{1}(t)||','C\gamma^t'); 
legend('C\gamma^t','||e_{1}(t)||')
%% ����������ͼ��    
t=0:tend-2;
figure
plot(t,lambda_sample_instant{1},'b.','linewidth',5);           
hold on
plot(t,lambda_sample_instant{2},'g.','linewidth',5);
hold on
plot(t,lambda_sample_instant{3},'r.','linewidth',5);
hold on
plot(t,lambda_sample_instant{4},'c.','linewidth',5);
hold on
plot(t,lambda_sample_instant{5},'m.','linewidth',5);
xlabel('Time[step]'); ylabel('Event sampling  time instants of five generators');
axis([0 tend 0.5 5.5]);